## Welcome to Coffee Bot

> #### Coffee Bot is an **open source** bot with some nifty features:
>
> - A *simple* yet **effective** reporting system which uses context menus to handle user and member reports (detailed examples with images on my top.gg page).
> - A Discord server invite filter, link filter and chat filter - all with an optional log channel.
>

### **For a detailed list of commands, features and examples, visit my [top.gg](https://top.gg/bot/950765718209720360) page!**

## [Invite Me!](https://discord.com/oauth2/authorize?client_id=950765718209720360&permissions=8&scope=bot%20applications.commands)
